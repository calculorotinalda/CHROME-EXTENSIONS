document.addEventListener("DOMContentLoaded", () => {
  document.getElementById("enable").onclick = async () => {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    chrome.tabs.sendMessage(tab.id, { action: "enable-translate" }, () => {
      if (chrome.runtime.lastError) {
        console.error("Content script não encontrado nesta aba!");
      } else window.close();
    });
  };
});

