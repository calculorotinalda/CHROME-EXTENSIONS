let active = false;

chrome.runtime.onMessage.addListener((req) => {
  if (req.action === "enable-translate") {
    active = true;
    showHint();
  }
});

document.addEventListener("mouseup", () => {
  if (!active) return;
  const text = window.getSelection().toString().trim();
  if (!text) return;

  active = false;

  chrome.runtime.sendMessage({ action: "translate", text }, (res) => {
    showPopup(res.translated);
  });
});

function showPopup(text) {
  document.getElementById("translator-popup")?.remove();
  const popup = document.createElement("div");
  popup.id = "translator-popup";
  popup.innerHTML = `<strong>Tradução</strong><p>${text}</p>`;
  document.body.appendChild(popup);
}

function showHint() {
  const hint = document.createElement("div");
  hint.id = "translator-hint";
  hint.innerText = "Seleciona o texto para traduzir";
  document.body.appendChild(hint);
  setTimeout(() => hint.remove(), 2000);
}
