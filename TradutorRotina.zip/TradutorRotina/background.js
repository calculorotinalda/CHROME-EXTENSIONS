chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === "translate") {
    const url = `https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=pt-PT&dt=t&q=${encodeURIComponent(msg.text)}`;
    fetch(url)
      .then(res => res.json())
      .then(data => {
        const translated = data[0].map(i => i[0]).join("");
        sendResponse({ translated });
      })
      .catch(() => sendResponse({ translated: "❌ Erro ao traduzir" }));
    return true; // importante para resposta assíncrona
  }
});


