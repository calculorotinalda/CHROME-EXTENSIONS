const upload = document.getElementById('upload');
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const widthInput = document.getElementById('width');
const heightInput = document.getElementById('height');

let image = null;
let dragging = false;
let startX = 0;
let startY = 0;

// ---------- UTIL ----------
function hasImage() {
  return image !== null;
}

function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(image, 0, 0);
}

// ---------- UPLOAD ----------
upload.addEventListener('change', () => {
  const file = upload.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = () => {
    image = new Image();
    image.onload = () => {
      canvas.width = image.naturalWidth;
      canvas.height = image.naturalHeight;
      draw();
      widthInput.value = canvas.width;
      heightInput.value = canvas.height;
    };
    image.src = reader.result;
  };
  reader.readAsDataURL(file);
});

// ---------- RESIZE ----------
document.getElementById('resize').addEventListener('click', () => {
  if (!hasImage()) return alert('Carregue uma imagem');

  const w = parseInt(widthInput.value, 10);
  const h = parseInt(heightInput.value, 10);
  if (!w || !h) return alert('Dimensões inválidas');

  const temp = document.createElement('canvas');
  temp.width = w;
  temp.height = h;
  temp.getContext('2d').drawImage(canvas, 0, 0, w, h);

  image = new Image();
  image.onload = () => {
    canvas.width = w;
    canvas.height = h;
    draw();
  };
  image.src = temp.toDataURL();
});

// ---------- CROP COM MOUSE (PRECISO) ----------
canvas.addEventListener('mousedown', (e) => {
  if (!hasImage()) return;

  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;

  startX = (e.clientX - rect.left) * scaleX;
  startY = (e.clientY - rect.top) * scaleY;
  dragging = true;
});

canvas.addEventListener('mousemove', (e) => {
  if (!dragging) return;

  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;

  const x = (e.clientX - rect.left) * scaleX;
  const y = (e.clientY - rect.top) * scaleY;

  draw();
  ctx.strokeStyle = 'red';
  ctx.lineWidth = 2;
  ctx.strokeRect(startX, startY, x - startX, y - startY);
});

canvas.addEventListener('mouseup', (e) => {
  if (!dragging) return;
  dragging = false;

  const rect = canvas.getBoundingClientRect();
  const scaleX = canvas.width / rect.width;
  const scaleY = canvas.height / rect.height;

  const endX = (e.clientX - rect.left) * scaleX;
  const endY = (e.clientY - rect.top) * scaleY;

  const x = Math.min(startX, endX);
  const y = Math.min(startY, endY);
  const w = Math.abs(endX - startX);
  const h = Math.abs(endY - startY);

  if (w < 5 || h < 5) {
    draw();
    return;
  }

  const temp = document.createElement('canvas');
  temp.width = w;
  temp.height = h;
  temp.getContext('2d').drawImage(canvas, x, y, w, h, 0, 0, w, h);

  image = new Image();
  image.onload = () => {
    canvas.width = w;
    canvas.height = h;
    draw();
    widthInput.value = w;
    heightInput.value = h;
  };
  image.src = temp.toDataURL();
});

// ---------- DOWNLOAD ----------
document.getElementById('download').addEventListener('click', () => {
  if (!hasImage()) return alert('Nada para download');
  const a = document.createElement('a');
  a.href = canvas.toDataURL('image/png');
  a.download = 'imagem-editada.png';
  a.click();
});
