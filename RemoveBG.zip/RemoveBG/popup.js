const upload = document.getElementById("upload");
const canvas = document.getElementById("canvas");
const ctx = canvas.getContext("2d");

const removeBtn = document.getElementById("remove");
const downloadBtn = document.getElementById("download");

let imageLoaded = false;

// 1️⃣ APENAS CARREGA A IMAGEM
upload.addEventListener("change", () => {
  const file = upload.files[0];
  if (!file) return;

  const img = new Image();
  img.onload = () => {
    canvas.width = img.width;
    canvas.height = img.height;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0);

    imageLoaded = true;
    downloadBtn.disabled = true;
  };
  img.src = URL.createObjectURL(file);
});

// 2️⃣ REMOVE BACKGROUND SÓ AO CLICAR NO BOTÃO
removeBtn.addEventListener("click", () => {
  if (!imageLoaded) {
    alert("Carregue uma imagem primeiro!");
    return;
  }

  const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
  const data = imageData.data;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];

    // Fundo branco ou quase branco
    if (r > 240 && g > 240 && b > 240) {
      data[i + 3] = 0;
    }
  }

  ctx.putImageData(imageData, 0, 0);
  downloadBtn.disabled = false;
});

// 3️⃣ DOWNLOAD SÓ DEPOIS DE REMOVER
downloadBtn.addEventListener("click", () => {
  const link = document.createElement("a");
  link.download = "imagem-sem-fundo.png";
  link.href = canvas.toDataURL("image/png");
  link.click();
});
