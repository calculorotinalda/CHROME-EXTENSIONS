let recorder;
let chunks = [];

chrome.runtime.onMessage.addListener(async msg => {
  if (msg.a === "record") {
    const stream = await navigator.mediaDevices.getDisplayMedia({
      video: true,
      audio: true
    });

    recorder = new MediaRecorder(stream);
    recorder.ondataavailable = e => chunks.push(e.data);

    recorder.onstop = () => {
      const blob = new Blob(chunks, { type: "video/webm" });
      const url = URL.createObjectURL(blob);

      const a = document.createElement("a");
      a.href = url;
      a.download = `record_${Date.now()}.webm`;
      a.click();

      chunks = [];
    };

    recorder.start();
  }

  if (msg.a === "stop" && recorder) {
    recorder.stop();
  }
});


