async function tab() {
  const [t] = await chrome.tabs.query({ active: true, currentWindow: true });
  return t;
}

document.getElementById("record").onclick = async () => {
  const t = await tab();
  await chrome.scripting.executeScript({
    target: { tabId: t.id },
    files: ["content.js"]
  });
  chrome.tabs.sendMessage(t.id, { a: "record" });
};

document.getElementById("stop").onclick = async () => {
  const t = await tab();
  chrome.tabs.sendMessage(t.id, { a: "stop" });
};

document.getElementById("capture").onclick = () => {
  chrome.tabs.captureVisibleTab(null, { format: "png" }, img => {
    chrome.downloads.download({
      url: img,
      filename: `screenshot_${Date.now()}.png`
    });
  });
};
