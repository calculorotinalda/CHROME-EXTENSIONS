chrome.runtime.onInstalled.addListener(() => {
console.log('Extensão instalada');
});