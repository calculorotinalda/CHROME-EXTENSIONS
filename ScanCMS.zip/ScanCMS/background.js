chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
if (msg.type === 'detect') {
sendResponse(msg.data);
}
});