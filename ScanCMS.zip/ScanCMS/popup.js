// Executa content.js na aba ativa
chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
  chrome.scripting.executeScript({
    target: { tabId: tabs[0].id },
    files: ['content.js']
  });
});

// Recebe mensagem do content.js
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === 'detect' && msg.data) {
    const cmsName = msg.data.cms;
    const pluginsList = msg.data.plugins;

    document.getElementById('cms').textContent = cmsName;

    const ul = document.getElementById('plugins');
    ul.innerHTML = '';

    if (!pluginsList || pluginsList.length === 0) {
      ul.innerHTML = '<li>Nenhum detetado</li>';
    } else {
      pluginsList.forEach(p => {
        const li = document.createElement('li');
        li.textContent = p;
        ul.appendChild(li);
      });
    }
  }
});
