(function () {
const html = document.documentElement.innerHTML.toLowerCase();
const scripts = [...document.scripts].map(s => s.src.toLowerCase());
const links = [...document.querySelectorAll('link')].map(l => l.href.toLowerCase());


let cms = 'Desconhecido';
let plugins = new Set();


// WordPress
if (html.includes('wp-content') || html.includes('wp-includes')) {
cms = 'WordPress';
[...scripts, ...links].forEach(u => {
const m = u.match(/wp-content\/plugins\/([^\/]+)/);
if (m) plugins.add(m[1]);
});
}


// Joomla
if (html.includes('joomla') || html.includes('/components/')) {
cms = 'Joomla';
[...scripts, ...links].forEach(u => {
const m = u.match(/\/components\/([^\/]+)/);
if (m) plugins.add(m[1]);
});
}


// Drupal
if (html.includes('drupal') || html.includes('/sites/all/')) {
cms = 'Drupal';
[...scripts, ...links].forEach(u => {
const m = u.match(/\/modules\/([^\/]+)/);
if (m) plugins.add(m[1]);
});
}


// OpenCart
if (html.includes('opencart') || html.includes('catalog/view')) {
cms = 'OpenCart';
[...scripts, ...links].forEach(u => {
const m = u.match(/\/extension\/([^\/]+)/);
if (m) plugins.add(m[1]);
});
}


chrome.runtime.sendMessage({
type: 'detect',
data: {
cms,
plugins: [...plugins]
}
});
})();